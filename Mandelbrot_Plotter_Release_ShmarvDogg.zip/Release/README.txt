This is the compiled and source code for a mandlebrot set plotter.

To use it just do either:

Mandelbrot_Plot.exe

or 

Mandelbrot_Plot.exe <rez>

with <rez> being the resolution of the image desired, both x and y are the same and are stated by 1 value e.g

500x500 is

Mandelbrot_Plot.exe 500

default rez is 500.